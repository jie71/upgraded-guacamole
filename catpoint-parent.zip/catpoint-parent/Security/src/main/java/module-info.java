module com.udacity.catpoint.security.service {
    requires miglayout;
    requires java.desktop;
    requires com.google.gson;
    requires com.google.common;
    requires java.prefs;
    requires com.udacity.catpoint.image.service;
    opens com.udacity.catpoint.security.service.data to com.google.gson;
}