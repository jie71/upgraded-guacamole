package com.udacity.catpoint.security.service.service;

import com.udacity.catpoint.image.service.FakeImageService;
import static org.junit.jupiter.api.Assertions.assertFalse;
import com.udacity.catpoint.image.service.ImageService;
import com.udacity.catpoint.security.service.application.StatusListener;
import com.udacity.catpoint.security.service.data.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Set;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class SecurityTest {

    private Sensor sensor;

    @Mock
    private StatusListener statusListener;

    @Mock
    SecurityRepository securityRepository;

    @Mock
    FakeImageService fakeImageService;

    @Mock
    private
    SecurityService securityService;

    @BeforeEach
    void setUp() {
        securityService = new SecurityService(securityRepository, fakeImageService);
        sensor = new Sensor("sensor", SensorType.DOOR);
        securityService.addSensor(sensor);
    }
    private Set<Sensor> getTestActiveSensors() {
        Set<Sensor> sensors = new HashSet<>();
        for (int i = 1; i <= 3; i++) {
            Sensor sense = new Sensor("Sensor " + i, SensorType.DOOR);
            sense.setActive(true);
            sensors.add(sense);
        }
        return sensors;
    }
    @ParameterizedTest
    @EnumSource(ArmingStatus.class)
    public void setArmingStatusMethod_runsThreeTimes(ArmingStatus armingStatus) {
        // method just to use @Parameterized test
        securityService.setArmingStatus(armingStatus);

    }
    // covers application requirement 1
    @Test
    void ifAlarmIsArmed_andSensorIsActivated_changeAlarmStatusToPending(){
        securityService.setArmingStatus(ArmingStatus.ARMED_HOME);
        when(securityService.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);
        securityService.changeSensorActivationStatus(sensor, true);
        verify(securityRepository, Mockito.times(1)).setAlarmStatus(AlarmStatus.PENDING_ALARM);
    }

    // covers application requirement 2
    @Test
    void ifAlarmIsArmed_andSensorIsActivated_andAlarmIsAlreadyPending_changeAlarmStatusToOn(){
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        securityService.changeSensorActivationStatus(sensor, true);
        verify(securityRepository, Mockito.times(1)).setAlarmStatus(AlarmStatus.ALARM);
    }

    // covers application requirement 3
    @Test
    void ifAlarmPending_andSensorsInactive_changeToNoAlarm(){
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        sensor.setActive(true);
        securityService.changeSensorActivationStatus(sensor, false);
        verify(securityRepository,times(1)).setAlarmStatus(AlarmStatus.NO_ALARM);

    }

    // covers application requirement 4
    // 4. If alarm is active, change in sensor state should not affect the alarm state.
    @ParameterizedTest
    @ValueSource(booleans = {true, false})
    public void alarmActive_changeSensor_doNotAffectAlarm(boolean sensorStatus) {
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);
        securityService.changeSensorActivationStatus(sensor, sensorStatus);
        verify(securityRepository, never()).setAlarmStatus(AlarmStatus.NO_ALARM);
        verify(securityRepository, never()).setAlarmStatus(AlarmStatus.PENDING_ALARM);
    }


    // covers application requirement 5
    @Test
    void ifSensorActivated_whileAlreadyActive_andSystemIsInPendingState_changeToAlarmState(){
        Mockito.when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        securityService.changeSensorActivationStatus(sensor, true);
        Mockito.verify(securityRepository, Mockito.times(1)).setAlarmStatus(any(AlarmStatus.class));
    }

    //  covers application requirement 6
    @Test
    void check_whenInactiveSensorDeactivated_noChangeInAlarmState() {
        sensor.setActive(false);
        Mockito.when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        securityService.changeSensorActivationStatus(sensor, false);
        Mockito.verify(securityRepository, never()).setAlarmStatus(any(AlarmStatus.class));

    }

    // covers application requirement 7
    @Test
    void ifImageContainsCat_whileTheSystemIsArmedHome_putSystemIntoAlarmStatus(){
        securityService.setArmingStatus(ArmingStatus.ARMED_HOME);
        when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        when(fakeImageService.imageContainsCat(any(), anyFloat())).thenReturn(true);
        securityService.processImage(mock(BufferedImage.class));
        verify(securityRepository, Mockito.times(1)).setAlarmStatus(AlarmStatus.ALARM);
    }

    // covers application requirement 8
    @Test
    void ifCatNotDetected_changeStatusToNoAlarm_asLongAsSensorInactive() {
        when(fakeImageService.imageContainsCat(any(), anyFloat())).thenReturn(false);
        securityService.processImage(mock(BufferedImage.class));
        securityService.changeSensorActivationStatus(sensor,false);
        verify(securityRepository).setAlarmStatus(AlarmStatus.NO_ALARM);
    }
    // covers application requirement 9
    @Test
    void ifSystemDisarmed_setStatusToNoAlarm(){
        securityService.setArmingStatus(ArmingStatus.DISARMED);
        verify(securityRepository, Mockito.times(1)).setAlarmStatus(AlarmStatus.NO_ALARM);
    }

    // covers application requirement 10
    @ParameterizedTest
    @EnumSource(value = ArmingStatus.class, names = {"ARMED_HOME", "ARMED_AWAY"})
    void ifSystemArmed_resetAllSensorsToInactive(ArmingStatus armingStatus){
        when(securityRepository.getSensors()).thenReturn(getTestActiveSensors());
        for (AlarmStatus alarmStatus : AlarmStatus.values()) {
            when(securityRepository.getAlarmStatus()).thenReturn(alarmStatus);
            securityService.setArmingStatus(armingStatus);
            for (Sensor s : securityService.getSensors()) {
                assertFalse(s.getActive());
            }
    }
    }

    // covers application requirement 11
    @Test
    void ifSystemArmed_whileCatDetected_setAlarmStatusToAlarm(){
        when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        when(fakeImageService.imageContainsCat(any(), anyFloat())).thenReturn(true);
        securityService.processImage(mock(BufferedImage.class));
        Mockito.verify(securityRepository,times(1)).setAlarmStatus(AlarmStatus.ALARM);
    }

    // following tests aren't part of the requirements, just added to get full coverage

    @Test
    void testAddAndRemoveStatusListener() {
        securityService.addStatusListener(statusListener);
        securityService.removeStatusListener(statusListener);
    }

    @Test
    void testAddAndRemoveSensor() {
        securityService.addSensor(sensor);
        securityService.removeSensor(sensor);
    }

    @Test
    void checkChangeSensorActivationStatusWorks_pendingAlam_withHandleSensorDeactivatedCovered(){
        Sensor sensor1 = new Sensor("testSensor",SensorType.DOOR);
        sensor1.setActive(true);
        securityRepository.setAlarmStatus(AlarmStatus.PENDING_ALARM);
        securityService.changeSensorActivationStatus(sensor, false);
        assert sensor.getActive().equals(false);
        verify(securityRepository, times(1)).setAlarmStatus(any(AlarmStatus.class));
    }

    @Test
    void test_handSensorActivated_whenRepositoryDisarmed_andAlarmOn_shouldTriggerHandleSensorDeactivated(){
        securityRepository.setArmingStatus(ArmingStatus.DISARMED);
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);
        sensor.setActive(true);
        securityService.changeSensorActivationStatus(sensor, false);
    }

    @Test
    void handSensorActivated_whenRepositoryDisarmed_andRepositoryAlarmPending_shouldTriggerHandleSensorDeactivated(){
        securityRepository.setArmingStatus(ArmingStatus.DISARMED);
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        sensor.setActive(true);
        securityService.changeSensorActivationStatus(sensor, false);
    }


    @Test
    void handSensorActivated_whenRepositoryDisarmed_andNoAlarm_shouldTriggerHandleSensorActivated(){
        when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.DISARMED);
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);
        sensor.setActive(false);
        securityService.changeSensorActivationStatus(sensor, true);
    }
}