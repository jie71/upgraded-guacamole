package api;

import Main.AdminMenu;
import model.Customer;
import model.IRoom;
import model.Reservation;
import model.Room;
import service.CustomerService;
import service.ReservationService;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class AdminResource {
    private final static  CustomerService customerService=CustomerService.getInstance();
    private final static  ReservationService reservationService=ReservationService.getInstance();

    public static List<Customer> getEmail(String email){
        List<Customer> c=customerService.getEmail(email);
        return c;
    }

    public static Customer getCustomer(String email){
        Customer c=customerService.getCustomer(email);
        return c;
    }

     public static void addRoom(List<IRoom> rooms){
         for (IRoom iroom:rooms) {
             reservationService.addRoom(iroom);
         }


    }

    public static IRoom getAllRooms(String roomNumber){
        IRoom room=reservationService.getARoom(roomNumber);
        return room;
    }
    public static List<IRoom> getAllRoom(){
        List<IRoom> iRoom= (List<IRoom>) reservationService.getAllRoom();
        return iRoom;
    }
    public static List<Customer> getAllCustomers(){
        List<Customer> list=customerService.getAllCustomers();
        return list;
    }
    public static void displayAllReservations(){
        reservationService.printlnAllReservation();
    }

}
