package api;

import model.Customer;
import model.IRoom;
import model.Reservation;
import service.CustomerService;
import service.ReservationService;

import java.util.Collection;
import java.util.Date;
import java.util.List;


public  class HotelResource {
    private final static  CustomerService customerService=CustomerService.getInstance();
    private final static  ReservationService reservationService=ReservationService.getInstance();


    public static void createACustomer (String email, String firstName, String lastName){
        customerService.addCustomer(email,firstName,lastName);
        }
        public static Reservation bookARoom (String customerEmail, IRoom room, Date checkInDate, Date checkOutDate ){
            for (Customer c:customerService.getAllCustomers()) {
                if (c.getEmail().equals(customerEmail)){
                        System.out.println("email:" + c.getEmail() + " book...");
                        reservationService.reserveRoom(c, room, checkInDate, checkOutDate);

                }
            }
            return null;
        }
        public static IRoom getRoomNumber(String roomNumber){
            IRoom iRoom=reservationService.getRoomNumber(roomNumber);
            return iRoom;
        }
        public static Collection<Reservation> getCustomerReservations(String customerEmail){
            for (Customer customer:customerService.getAllC()) {
                if(customer.getEmail().equals(customerEmail)){
                    reservationService.getCustomersReservation(customer);
                }
            }

            return null;
        }
        public static List<IRoom> findARoom (Date checkIn, Date checkOut){
            List<IRoom> iRooms=reservationService.findRooms(checkIn,checkOut);
            return iRooms;
        }

}
