package Main;

import api.AdminResource;
import api.HotelResource;
import model.*;
import service.CustomerService;
import service.ReservationService;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AdminMenu {
    public  static void startAdminMenu(){
        Scanner sc=new Scanner(System.in);
        boolean flag1=true;
        while (flag1) {
            System.out.println("Admin Menu");
            System.out.println("-----------------------------------------");
            System.out.println("1.See all Customers");
            System.out.println("2.See all Rooms");
            System.out.println("3.See all Reservations");
            System.out.println("4.Add a Room");
            System.out.println("5.Back to Main Menu");
            System.out.println("-----------------------------------------");
            System.out.println("Please select a number for the menu option");
            String number = sc.next();
            switch (number){
//            allcustomersStart
                case "1":
                    for (Customer customer:AdminResource.getAllCustomers()) {
                        System.out.println(customer);
                    }
            break;
//            allcustomersStop
//            allroomStart
                case "2":
                    for (IRoom iRoom:AdminResource.getAllRoom()) {
                        System.out.println(iRoom);
                    }
            break;
//            allroomStop
//            allreservationsStart
                case "3":
                AdminResource.displayAllReservations();
            break;
//            allreservationsStop
//            addRoomStart
                case "4":
                boolean addRoom=true;
                while(addRoom) {
                    Room room =new Room();
                    boolean addRTyoom = true;
                    System.out.println("Enter Room Number:");
                    String roomNumber = sc.next();
                        if (AdminResource.getAllRooms(roomNumber) == null) {
                            System.out.println("success");
                            room.setRoomNumber(roomNumber);
                            System.out.println("Enter price per night:");
                            String Price = sc.next();
                            double price = Double.valueOf(Price);
                            room.setPrice(price);
                            while (addRTyoom) {
                                System.out.println("Enter room type:1.single bed, 2.double bed");
                                String roomType = sc.next();
                                if (roomType.equals("1")) {
                                    room.setEnumeration(RoomType.SINGLE);
                                    addRTyoom = false;
                                } else if (roomType.equals("2")) {
                                    room.setEnumeration(RoomType.DOUBLE);
                                    addRTyoom = false;
                                } else {
                                    System.out.println("-------Please Enter Correct Number-------");
                                }
                            }
                            boolean yesorno=true;
                            while (yesorno){
                            System.out.println("would you like to add another room?");
                            System.out.println("Please Enter Y(Yes) or N(No) y/n");
                            String string = sc.next();
                            if (string.equals("Y") || string.equals("y")) {
                                addRoom = true;
                                yesorno=false;
                                List<IRoom> roomList=new ArrayList<IRoom>();
                                roomList.add(room);
                                AdminResource.addRoom(roomList);
                            } else if (string.equals("N") || string.equals("n")) {
                                addRoom = false;
                                yesorno=false;
                                List<IRoom> roomList=new ArrayList<IRoom>();
                                roomList.add(room);
                                AdminResource.addRoom(roomList);
                            }else {
                            }

                            }

                        }else {
                            System.out.println("roomNumber exist,please try again");
                            addRoom=false;
                        }
                }

            break;
//            addRoomStop
            case "5":
                flag1=false;
                System.out.println("Return Main Menu!");
            break;
        }
    }
    }
}
