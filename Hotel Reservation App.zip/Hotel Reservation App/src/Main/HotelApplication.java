package Main;



public class HotelApplication {
    public static void main(String[] args) {
        MainMenu m=new MainMenu();
        m.startMainMenu();
    }
}
