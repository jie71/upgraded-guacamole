package Main;

import api.AdminResource;
import api.HotelResource;
import model.Customer;
import model.IRoom;
import model.Room;
import service.CustomerService;
import service.ReservationService;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

public class MainMenu {
    public static void startMainMenu(){
        Scanner sc=new Scanner(System.in);
        boolean flag =true;
        System.out.println("Welcome to my Hotel");
        while(flag){
            boolean flag1 =true;
            System.out.println("MainMenu");
            System.out.println("-----------------------------------------");
            System.out.println("1.Find and reserve a room");
            System.out.println("2.See my reservations");
            System.out.println("3.Create an account");
            System.out.println("4.Admin");
            System.out.println("5.Exit");
            System.out.println("-----------------------------------------");
            System.out.println("Please select a number for the menu option");
            String mm=sc.next();
//            reserve room start
            switch (mm) {
                case "1":
                    boolean reserve = true;
                    boolean reserveflag = true;
                    boolean reserveflag1 = true;
                    while (reserve) {
                        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                        System.out.println("Enter CheckIn Date mm/dd/yyyy 11/27/2021");
                        String checkInDate = sc.next();
                        Date date = null;
                        try {
                            date = dateFormat.parse(checkInDate);
                            reserveflag = true;
                        } catch (ParseException e) {
                            e.printStackTrace();
                            reserveflag = false;
                        }
                        if (reserveflag) {

                            System.out.println("Enter CheckOut Date mm/dd/yyyy 11/28/2021");
                            String checkOutDate = sc.next();
                            Date date1 = null;
                            try {
                                date1 = dateFormat.parse(checkOutDate);
                                reserveflag1 = true;
                            } catch (ParseException e) {
                                e.printStackTrace();
                                reserveflag1 = false;
                            }
                            List<IRoom> available=HotelResource.findARoom(date,date1);
                            if (reserveflag1) {
                                for (IRoom iRoom:available) {
                                        System.out.println(iRoom);
                                }
                                System.out.println("would u like to book a room? y/n");
                                String string = sc.next();
                                if (string.equals("Y") || string.equals("y")) {
                                    System.out.println("Do You Have an account with us? y/n ");
                                    String string1 = sc.next();
                                    if (string1.equals("Y") || string1.equals("y")) {
                                        System.out.println("Enter Email format:name@example.com");
                                        String checkEmail = sc.next();
                                        for (Customer c:CustomerService.getInstance().getAllC()) {
                                            if (c.getEmail().equals(checkEmail)) {
                                                boolean runRoom = true;
                                                while (runRoom) {
                                                    System.out.println("what room number would you like to reserve?");
                                                    String roomNumber = sc.next();
                                                    IRoom iRoom = HotelResource.getRoomNumber(roomNumber);
                                                    if (iRoom != null) {
                                                        HotelResource.bookARoom(checkEmail, iRoom, date, date1);
                                                        reserve = false;
                                                        runRoom = false;
                                                    } else {

                                                    }
                                                }
                                            }
                                        }



                                    } else if (string1.equals("N") || string1.equals("n")) {
                                        System.out.println("please create an account first");
                                        reserve = false;
                                    } else {
                                        System.out.println("please enter Y/N  y/n");
                                    }
                                } else if (string.equals("N") || string.equals("n")) {
                                    System.out.println("stop");
                                    reserve = false;
                                } else {
                                    System.out.println("please enter Y/N  y/n");
                                }
                            } else {
                                System.out.println("incorrect format,please try again");
                            }
                        } else {
                            System.out.println("please try again");
                        }
                    }
                break;

//            reserve room stop
//                see my reservations start
                case "2":
                    System.out.println("please enter your email:");
                    String email1 =sc.next();
                    HotelResource.getCustomerReservations(email1);
                    break;
//                see my reservations stop
//            creat an account start
                case "3":
                boolean createAcc = true;
                while (createAcc) {
                    System.out.println("Enter Email format:name@hotmail.com");
                    String email=sc.next();
                        if (AdminResource.getCustomer(email) == null) {
                            System.out.println("Enter firstName:");
                            String FirstName = sc.next();
                            System.out.println("Enter lastName:");
                            String LastName = sc.next();
                            boolean yesorno=true;
                            while(yesorno) {
                                System.out.println("would you like to add another account?please enter yes y/n");
                                String test = sc.next();
                                if (test.equals("Y") || test.equals("y")) {
                                    System.out.println("continue");
                                        HotelResource.createACustomer(email, FirstName, LastName);
                                    createAcc = true;
                                    yesorno=false;
                                } else if (test.equals("N") || test.equals("n")) {
                                    System.out.println("stop");
                                        HotelResource.createACustomer(email, FirstName, LastName);
                                    createAcc = false;
                                    yesorno=false;
                                }else{

                                }
                            }
                        } else {
                            System.out.println("email exist,please try again");
                            createAcc = false;
                        }

                }
                break;
//            create an account stop
//            AdminStart
                case "4":
                AdminMenu.startAdminMenu();
                break;
//            AdminStop

//            exit start
                case "5":
                System.out.println("exit success!");
                flag=false;
                break;
//            exit stop
        }
    }
    }
}
