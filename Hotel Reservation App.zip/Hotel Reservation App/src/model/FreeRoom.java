package model;

public class FreeRoom extends Room {
    private double price =0;
    public FreeRoom() {
    }

    public FreeRoom(String roomNumber, Double price, RoomType enumeration) {
        super(roomNumber, 0.0, enumeration);
    }
}
