package model;

import Main.AdminMenu;
import Main.MainMenu;
import api.AdminResource;
import api.HotelResource;
import service.CustomerService;
import service.ReservationService;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

public class Tester {
    public static void main(String[] args) {
        int i=5;
        int j=2;
        boolean m=i<j;
        System.out.println(!m);
        /*SimpleDateFormat simpleDateFormat=new SimpleDateFormat("MM/dd/yyyy");
        SimpleDateFormat simpleDateFormat1=new SimpleDateFormat("MM/dd/yyyy");
        Date date=null;
        Date date1=null;
        try {
            date=simpleDateFormat.parse("1/3/1111");
            date1=simpleDateFormat1.parse("1/3/1111");
            System.out.println(simpleDateFormat.format(date));
            System.out.println(simpleDateFormat.format(date1));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if (date.after(date1)) {
            System.out.println("Date1 is after Date2");
        }

        if (date.before(date1)) {
            System.out.println("Date1 is before Date2");
        }

        if (date.equals(date1)) {
            System.out.println("Date1 is equal Date2");
        }*/
        /*Customer c1=new Customer("asd","asdas","asdda@a.com");
        Customer c2=new Customer("asd","asdas","asdda@a.com");
        System.out.println(c1.hashCode());
        System.out.println(c2.hashCode());*/
        /*Customer c=new Customer("asd","asdas","asdda@a.com");
        System.out.println(c);*/
        /*MainMenu m=new MainMenu();
        m.startMainMenu();*/
        /*String str = "9/5/2021";
        SimpleDateFormat date = new SimpleDateFormat("MM/dd/yyyy");

        try {
            Date d=date.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }*/
    }

        /*Customer c=new Customer();
        c.setFirstName("first");
        c.setLastName("last");
        c.setEmail("email");
        Room r=new Room("A100",100.0,RoomType.SINGLE);
        Calendar calendar = Calendar.getInstance();
        int year=2020;
        int month=01;
        int date11=05;
        calendar.set(year,month,date11);
        Date date = calendar.getTime();
        Reservation rs=new Reservation(c,r,date,date);
        System.out.println(rs);*/



        /*Room room=new Room();
        Customer c=new Customer();
        c.setEmail("w@hot.com");
        Reservation rs=new Reservation();
        rs.setCustomer(c);
        Calendar calendar = Calendar.getInstance();
        int year=2020;
        int month=01;
        int date11=05;
        calendar.set(year,month,date11);
        Date date = calendar.getTime();
        rs.setCheckInDate(date);
        Calendar calendar1 = Calendar.getInstance();
        calendar.set(2021, 01, 01);
        Date date1 = calendar.getTime();
        rs.setCheckOutDate(date1);
        room.setPrice(100.0);
        room.getPrice();
        System.out.println(rs);*/



       /* Scanner sc=new Scanner(System.in);
        String i=sc.next();
        String verify="[a-z]";
        String verify1="[A-Z]";
        Pattern pattern=Pattern.compile(verify);
        Pattern pattern1=Pattern.compile(verify1);
        if(pattern.matcher(i).matches()){
            System.out.println("这个小写字符串");
        }else if (pattern1.matcher(i).matches()){
            System.out.println("这个大写字符串");
        }else{
            System.out.println("输入的是号码" );
        }*/

    }

