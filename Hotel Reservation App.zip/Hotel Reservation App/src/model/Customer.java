package model;

import java.util.Objects;
import java.util.regex.Pattern;

public class Customer {
    private final String  firstName;
    private final String lastName;
    private final String email;

    public Customer(String firstName, String lastName, String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        String regex = "^(.+)@(.+).com$";
        Pattern pattern = Pattern.compile(regex);
        if (pattern.matcher(email).matches()) {
            System.out.println("email format correct");
        } else {
            try {
                throw new IllegalArgumentException("email format:'name@hotmail.com',  please try again");
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }
        }
    }

    public String getFirstName() {
        return firstName;
    }


    public String getLastName() {
        return lastName;
    }


    public String getEmail() {
        return email;
    }


    @Override
    public String toString() {
        return
                " firstName='" +firstName + '\n' +
                " lastName='" + lastName + '\n' +
                " email='" + email + '\n' ;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Customer customer = (Customer) o;
        return firstName.equals(customer.firstName) &&
                lastName.equals(customer.lastName) &&
                email.equals(customer.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName, email);
    }
}
