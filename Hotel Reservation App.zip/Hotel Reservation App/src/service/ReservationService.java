package service;

import model.Customer;
import model.IRoom;
import model.Reservation;
import model.Room;

import javax.swing.text.html.HTMLDocument;
import java.util.*;

public class ReservationService  {
    private static List<IRoom> roomList=new ArrayList<IRoom>();
    private static List<Reservation> reservationList=new ArrayList<Reservation>();
    private static ReservationService reservationService=null;




    public static ReservationService getInstance(){
        if (null == reservationService) {
            reservationService = new ReservationService();
        }
        return reservationService;
    }

    public ReservationService() {
    }

    public  void addRoom(IRoom rooms){
         roomList.add(rooms);
    }
    public  IRoom getARoom(String roomNumber){
        Iterator<IRoom> it=roomList.iterator();
        while(it.hasNext()){
            IRoom room=it.next();
            if(room.getRoomNumber().equals(roomNumber)){
                try {
                    throw new IllegalArgumentException(checkRoomNumberExist());
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                }return room;
            }else{
                System.out.println("");
                return null;
            }
        }
        return null;
    }
    public  Reservation reserveRoom(Customer customer, IRoom room, Date checkInDate,Date checkOutDate ){
        Reservation reservation=new Reservation(customer,room,checkInDate,checkOutDate);
        reservationList.add(reservation);
        return reservation;
    }
    public  List<IRoom> findRooms(Date checkInDate,Date checkOutDate){
        List<IRoom> availableRooms = new ArrayList<IRoom>();
        if(reservationList.size() == 0) {
            availableRooms = roomList;
            return availableRooms;
        }
        else {
            for(Reservation reservation : reservationList) {
                for (IRoom iRoom : roomList) {
                    if ((iRoom.getRoomNumber().equals(reservation.getRoom().getRoomNumber()))
                            && ((checkInDate.before(reservation.getCheckInDate()) && checkOutDate.before(reservation.getCheckInDate()))
                            || (checkInDate.after(reservation.getCheckOutDate()) && checkOutDate.after(reservation.getCheckOutDate())))
                            || (!reservation.getRoom().getRoomNumber().contains(iRoom.getRoomNumber()))) {
                        availableRooms.add(iRoom);

                    } else if (iRoom.getRoomNumber().equals(reservation.getRoom().getRoomNumber())) {
                        availableRooms.remove(iRoom);
                        if(reservationList.size()>=roomList.size()){
                            System.out.println("The room is full, please change the date");
                        }
                    }
                }

            }
        }
        return availableRooms;

    }
    public    List<IRoom>  getAllRoom(){
        for (IRoom iRoom:roomList) {
            return roomList;
        }
        return null;
    }
    public   IRoom getRoomNumber(String roomNumber){
        for (IRoom iRoom:roomList) {
            if(iRoom.getRoomNumber().equals(roomNumber)){
//                roomNumBer exist
                return iRoom;
            }else{
                try {
                    throw new IllegalArgumentException("can't find roomNumber");
                } catch (Exception e) {
                    e.printStackTrace();
                }return null;
            }
        }return null;
    }
    public  Collection<Reservation> getCustomersReservation(Customer customer){
        for (Reservation reservation:reservationList) {
            if(reservation.getCustomer().getEmail().equals(customer.getEmail())){
                System.out.println(reservation);
                return reservationList;
            }else{
                return  null;
            }
        }
        return null;
    }


    public  void printlnAllReservation(){
        for (Reservation reservation:reservationList) {
            System.out.println(reservation);
        }
    }
//    default method
    String checkRoomNumberExist(){
        return "RoomNumberExist";
    }
}
