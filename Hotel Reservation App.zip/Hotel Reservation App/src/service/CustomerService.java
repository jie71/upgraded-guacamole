package service;

import model.Customer;

import javax.crypto.Cipher;
import java.util.*;

public class CustomerService {
    private static CustomerService customerService=null;
    public  static CustomerService getInstance(){
        if (null == customerService) {
            customerService = new CustomerService();
        }
        return customerService;
    }

    public CustomerService() {
    }

    private  List<Customer> customerList=new ArrayList<Customer>();
        public  void addCustomer (String email, String firstName, String lastName){
            Customer customer=new Customer(firstName,lastName,email);
            customerList.add(customer);
        }

    public   Customer getCustomer (String customerEmail){
            for (Customer customer:customerList) {
                if(customer.getEmail().equals(customerEmail)){
                    try {
                        throw new IllegalArgumentException("Email Exist");
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    }
                    return customer;
                }else{
                    return null;
                }
            }return null;
        }
        public   List<Customer> getEmail(String email){
            for (Customer customer:customerList){
                if(customer.getEmail().equals(email)){
                    System.out.println(exist());
                    return customerList;
                }else{
                    try {
                        throw new NullPointerException("can't find email,please create an account first");
                    } catch (NullPointerException e) {
                        e.printStackTrace();
                    }
                    return null;
                }
            }
            return null;
        }

        public  List<Customer> getAllCustomers () {
            return customerList;
        }
    public  List<Customer> getAllC() {
        for (Customer c:customerList) {
            return customerList;
        }
        return null;
    }
    private String exist(){
            return "Email Exist";
    }

    }



